const bodyParser = require('body-parser'); 
const bcrypt= require('bcrypt');// Replaced ES6 import with CommonJS require
const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');

// Replace ES6 imports with CommonJS requires
const userRoutes = require('./routes/userRoute');
const buyersRoutes = require('./routes/buyerRoutes');
const wishlistRoutes = require('./routes/wishlistRoutes');
require('dotenv/config'); // Import environment variables from .env file
const noAuthRouter = require('./routes/noAuthRoutes');
const { verifyJwt } = require('./services/jwtAuthService'); // Destructure the verifyJwt function from jwtAuthService

const app = express();

app.use(cors({
  origin: '*',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.options('*', cors());
app.use(bodyParser.json());
app.use('/', noAuthRouter);
app.use('/users', verifyJwt, userRoutes);
app.use('/buyers', buyersRoutes);
app.use('/wishlist', wishlistRoutes);

mongoose.connect('mongodb+srv://ITCC:x3txwwBMqr1bQZnR@atlascluster.30o4fpw.mongodb.net/RealEstate?retryWrites=true&w=majority&appName=AtlasCluster')
  .then(() => {
    console.log('DB Connected');
    app.listen(3002, () => {
      console.log('Server started on port 3002');
    });
  })
  .catch((e) => {
    console.log(e);
  });
